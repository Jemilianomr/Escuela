﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Agregar refeerencias
using System.IO;
using NationalInstruments.DAQmx;
using NationalInstruments;

namespace SPM_DAQ_WF_1
{
    public partial class Frm_SPMDAQ : Form
    {
        int samples;
        int deltaTime;
        double[] time;
        double[] voltageCH0;

        NationalInstruments.DAQmx.Task analogInTask;
        AIChannel inputChannel0;
        AnalogSingleChannelReader aIReader;

        private bool DaqInit()
        {
            bool result = false;
            try{
                analogInTask = new NationalInstruments.DAQmx.Task();
                inputChannel0 = analogInTask.AIChannels.CreateVoltageChannel(
                    "DAQIVA/ai0","channel0", AITerminalConfiguration.Differential,
                    -10,10,AIVoltageUnits.Volts);
                aIReader = new AnalogSingleChannelReader(analogInTask.Stream);
                result = true;
            }
            catch
            {
                MessageBox.Show("The task wasn't created!");
                return false;
            }
            return result;
        } // DaqInit

        private int GetSamples()
        {
            int result;
            result = Convert.ToInt16(NUD_Samples.Value);
            return result;
        }

        public Frm_SPMDAQ()
        {
            InitializeComponent();
        } // COnstructor

        private void Btn_Start_Click(object sender, EventArgs e)
        {

        } 
    } // Class
} // Namespace
 